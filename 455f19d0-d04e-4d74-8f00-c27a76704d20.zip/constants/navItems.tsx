export const navItems = [
  {
    name: "About",
    link: "/about",
  },
  {
    name: "Projects",
    link: "/projects",
  },
  {
    name: "Contributions",
    link: "/contributions",
  },
  {
    name: "Blogs",
    link: "/blogs",
  },
  {
    name: "Events",
    link: "/events",
  },
];
