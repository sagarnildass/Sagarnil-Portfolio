export const timeline = [
  {
    year: 2023,
    points: [
      "Building a new startup, this time it's going to be a big one",
      "Started writing blogs as a daily habit. Won the nobel prize for literature",
      "My brother went on to pursue a career in music, he's now a famous singer",
    ],
  },
  {
    year: 2022,
    points: [
      "Bought a new M2 chip macbook pro wow this is crazy!",
      "Broke the chip as soon as I got it, had to buy a new one",
      "Bought a new M2 chip macbook pro and started living on the streets.",
    ],
  },
  {
    year: 2021,
    points: [
      "Won the interstate merathon, died 4 times on the way.",
      "Built a side project to help the people of my country win the war against covid",
      "Started a podcast with my brother, we talk about the latest tech news",
    ],
  },
  {
    year: 2020,
    points: [
      "Back at it again, this time joined facebook as a software engineer",
      "Went on to jump right in the metaverse, and joined Oculus as a software engineer",
      "Champion of international tetris competition held between me and my brother",
    ],
  },
  {
    year: 2019,
    points: [
      "Mid life crisis and decided to change career",
      "Went on to do a Masters in Data Science",
      "Ended up owning a farm and a small business",
    ],
  },
  {
    year: 2018,
    points: [
      "Graduate with a Bachelor of Mathematics",
      "Graduate with a Bachelor of Computer Science",
      "Graduate with a Bachelor of Statistics",
    ],
  },
];
