export const uses = [
  {
    name: "16 Inch M2 MacBook Pro",
    description: `My main machine for development that I've been using for over 6 months now. Such a beast of a machine. I love it.`,
  },
  {
    name: "iPad Pro 12.9",
    description: `Overrated in my opinion. I use it for reading books and watching movies. I don't use it for development.`,
  },
  {
    name: "Keychron K2",
    description:
      "My main keyboard for development. I love the clicky keys and the compact size. I use it with a Logitech MX Master 3 mouse.",
  },
  {
    name: "Logitech MX Master 3",
    description:
      "My main mouse for development. I love the scroll wheel and the thumb buttons. I use it with a Keychron K2 keyboard.",
  },
];
