export const user = {
  github: "https://github.com/manuarora700",
  twitter: "https://twitter.com/mannupaaji",
  linkedin: "https://www.linkedin.com/in/manuarora28/",
};
